#pragma once

#include "../Core/SDK.h"
#include "../Menu/Config.h"
#include "../Menu/Render.h"
#include "References.h"


namespace Cheat
{
    void PlayerEnemyESP();
    void CollectibleESP();
    void DrawTeleportPreviewSpheres();
}
