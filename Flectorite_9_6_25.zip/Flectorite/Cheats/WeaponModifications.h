#pragma once

#include "References.h"
#include "../Core/SDK.h"
#include "../Menu/Config.h"
#include "../Menu/Render.h"

namespace Cheat
{
    void WeaponModifications();
    void ModifyGrapple();
}
