#pragma once

#include "References.h"
#include "../Core/SDK.h"
#include "../Menu/Config.h"
#include "../Menu/Render.h"
#include <chrono>
#include <unordered_map>
#include <string>

namespace Cheat
{
    void MissionESPTeleport();
    void AutoRestartMission();
    void InstantInfiltration();
    void MissionTaskTeleporter();
}
